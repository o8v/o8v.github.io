#include <iostream>
#include <algorithm>
#include <string>

using namespace std;

int main() {
  string s;

  for (int test = 0; test < 5; test += 1) {
    getline(cin, s);
    next_permutation(begin(s), end(s));
    cout << s << "\n";
  }  

  return 0;
}