t = input()
p = input()

a = sorted(p)
k = 0
for i in range(len(t) - len(p) + 1):
  b = sorted(t[i : i + len(p)])
  if a == b:
    k += 1

print(k)
