﻿#include "testlib.h"

using namespace std;

int main() {
  registerValidation();

  string t = inf.readString();
  ensure(t.size() < 100000);

  string p = inf.readString();
  ensure(p.size() < 100000);

  inf.readEof();
  return 0;
}
