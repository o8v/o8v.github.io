t = input()
p = input()

a = {}
for c in p:
  if c not in a:
    a[c] = 0
  a[c] -= 1

f = len(a)
def change(c, delta):
  global f
  if c not in a: return    
  if a[c] == 0:
    f += 1
  elif a[c] + delta == 0:
    f -= 1
  a[c] += delta

k = 0
for i in range(len(t)):
  if i >= len(p):
    change(t[i - len(p)], -1)
  change(t[i], 1)
  if f == 0:
    k += 1
print(k)