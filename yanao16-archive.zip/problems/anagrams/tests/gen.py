﻿from random import seed, shuffle, choice, sample, randrange as rr
seed(1727)

test_number = 1
def write_test(t, p):
  global test_number
  o = open("%02d" % test_number, "w")
  print(t, file = o)
  print(p, file = o)
  o.close()
  test_number += 1

def init(p):
  d = {}
  for c in p:
    if c not in d:
      d[c] = 0
    d[c] -= 1
  return p, [], d, set(d)

"""
1) Append k random letters from the given collection.
2) Append letters to have k occurences in the suffix.
"""
def fix(d, req, c, delta):
  if c in d:
    d[c] += delta
    if d[c] >= 0:
      req.discard(c)
    else:
      req.add(c)
def p1(p, a, d, req, s, k):
  for i in range(k):
    if len(a) >= len(p):
      fix(d, req, a[-len(p)], -1)
    c = choice(s)
    if c in d:
      fix(d, req, c, 1)
    a.append(c)
def p2(p, a, d, req, k):
  if len(req) == 0:
    k -= 1
  while k > 0:
    if len(a) >= len(p):
      fix(d, req, a[-len(p)], -1)
    c = choice(sorted(req))
    if c in d:
      fix(d, req, c, 1)
    a.append(c)
    if len(req) == 0:
      k -= 1

"""
Concatenate k random permutations of the given string.
"""
def c1(p, k, s, n):
  a = list(p)
  t = []
  t.extend(sample(s, n))
  for i in range(k):
    shuffle(a)
    t.extend(a)
    t.extend(sample(s, n))
  return "".join(t)

ALPHA = "".join([chr(i + ord('a')) for i in range(26)])

# small tests, <= 100
write_test("bbabbbaabba", "bba")
write_test("bbacbbaabbcabbc", "abc")
write_test("".join([choice("qwertyuiop") for i in range(30)]),
  "".join([choice("qwertyuiop") for i in range(10)]))
write_test(c1("hello", 4, "", 0), "hello")
write_test(c1("hello", 4, "hello", 2), "hello")
write_test(c1("ab", 10, "aaabbaaabb", 5), "ab")

p, a, d, req = init("".join([choice(ALPHA) for i in range(8)]))
for i in range(10):
  p1(p, a, d, req, p, 3)
  p2(p, a, d, req, 3)
write_test("".join(a), p)

p, a, d, req = init("".join([choice(ALPHA) for i in range(25)]))
for i in range(7):
  p1(p, a, d, req, p, 1)
  p2(p, a, d, req, 5)
write_test("".join(a), p)

p, a, d, req = init("".join([choice(ALPHA) for i in range(60)]))
for i in range(3):
  p1(p, a, d, req, p, 1)
  p2(p, a, d, req, rr(5, 7))
write_test("".join(a), p)

write_test("".join([choice(ALPHA) for i in range(99)]), "q")

# > 100
write_test("".join([choice("ab") for i in range(99999)]),
  "".join([choice("ab") for i in range(50000)]))

p, a, d, req = init("".join([choice(ALPHA) for i in range(50000)]))
p1(p, a, d, req, ALPHA, 20000)
p2(p, a, d, req, 17)
p1(p, a, d, req, ALPHA, 20000)
write_test("".join(a), p)

p, a, d, req = init("".join([choice(ALPHA) for i in range(50000)]))
for i in range(100):
  p1(p, a, d, req, ALPHA, rr(20, 50))
  p2(p, a, d, req, rr(50, 70))
write_test("".join(a), p)

p, a, d, req = init("".join([choice(ALPHA) for i in range(90000)]))
for i in range(45):
  p1(p, a, d, req, ALPHA, rr(20, 50))
  p2(p, a, d, req, rr(50, 70))
write_test("".join(a), p)

p, a, d, req = init("".join([choice(ALPHA[1:]) for i in range(2000)]))
for i in range(55):
  p1(p, a, d, req, ALPHA, rr(20, 50))
  p2(p, a, d, req, rr(50, 70))
write_test("".join(a), p)

