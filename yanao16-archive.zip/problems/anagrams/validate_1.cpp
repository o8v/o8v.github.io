﻿#include "testlib.h"

using namespace std;

int main() {
  registerValidation();

  string t = inf.readString();
  ensure(t.size() < 100);

  string p = inf.readString();
  ensure(p.size() < 100);

  inf.readEof();
  return 0;
}
