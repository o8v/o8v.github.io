#include <iostream>
#include <array>
#include <vector>

using namespace std;

int main() {
  string t, p;
  getline(cin, t);
  getline(cin, p);

  vector<int> letters;
  array<int, 26> a;
  a.fill(0);
  for (char c : p) {
    a[c - 'a'] += 1;
    if (a[c - 'a'] == 1)
      letters.push_back(c - 'a');
  }

  int k = 0;
  array<int, 26> b;
  for (int i = 0; i + p.size() <= t.size(); i += 1) {
    for (int x : letters)
      b[x] = 0;

    int z = letters.size();
    for (int j = i; j < i + p.size(); j += 1) {
      int x = t[j] - 'a';
      if (a[x] > 0) {
        b[x] += 1;
        if (b[x] > a[x])
          break;
        if (b[x] == a[x])
          z -= 1;
      }
    }
    if (z == 0)
      k += 1;
  }

  cout << k << endl;  
  return 0;
}