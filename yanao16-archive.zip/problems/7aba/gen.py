﻿import random

random.seed(1729)

def g(res, up):
  x = 2 ** res
  p = 2 * x
  while x + p <= up:
    if random.randint(0, 1) == 1:
      x += p
    p = 2 * p
  return x

o = open("01", "w")

print(g(2, 20), file = o)
print(g(4, 2 ** 8), file = o)
print(g(7, 2 ** 9), file = o)
print(g(15, 2 ** 19), file = o)
print(g(11, 2 ** 26), file = o)


o.close()