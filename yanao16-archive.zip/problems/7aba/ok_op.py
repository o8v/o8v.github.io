a = [chr(i + ord('a')) for i in range(26)]

def f(x):
  k = 0
  while x % 2 == 0:
    x = x / 2
    k += 1
  return a[k]

for test in range(5):
  n = int(input())
  print(f(n))
