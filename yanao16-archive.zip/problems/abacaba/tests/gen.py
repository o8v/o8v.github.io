﻿import random
random.seed(1719)

test_number = 1
def write_test(x):
  global test_number
  o = open("%02d" % test_number, "w")
  print(x, file = o)
  o.close()
  test_number += 1

def g(res, up):
  x = 2 ** res
  p = 2 * x
  while x + p <= up:
    if random.randint(0, 1) == 1:
      x += p
    p = 2 * p
  return x


a = list(range(6))
random.shuffle(a)
b = a[:]
random.shuffle(a)
b.extend(a)
for i in range(10):
  write_test(g(b[i], 50))

a = list(range(10)) + list(range(6, 10))
b = list(random.sample(a, 10))
random.shuffle(b)
for i in range(10):
  write_test(g(b[i], 1000))

b = list(range(10, 20))
random.shuffle(b)
for i in range(10):
  write_test(g(b[i], 1000000))

b = list(range(20, 30))
random.shuffle(b)
for i in range(10):
  write_test(g(b[i], 1000000000))
