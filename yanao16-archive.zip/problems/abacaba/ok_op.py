aA = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
n = int(input())
k = 0
while n % 2 == 0:
  n = n / 2
  k += 1
print(aA[k])
