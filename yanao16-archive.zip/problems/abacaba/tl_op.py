n = int(input())
s = ""
for c in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ":
  s = s + c + s
  if len(s) >= n:
    break
print(s[n - 1])
