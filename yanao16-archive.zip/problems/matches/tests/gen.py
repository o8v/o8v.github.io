﻿from random import seed, randrange as rr
seed(1720)

test_number = 1
def write_test(x):
  global test_number
  o = open("%02d" % test_number, "w")
  print(x, file = o)
  o.close()
  test_number += 1

for i in range(10):
  write_test(i)

for i in range(10):
  write_test(rr(100, 100000))

for i in range(10):
  x = str(rr(1, 10))
  y = [str(rr(10)) for i in range(rr(50, 100))]
  write_test(x + "".join(y))
