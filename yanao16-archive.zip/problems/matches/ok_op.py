a = [6, 2, 5, 5, 4, 5, 6, 3, 7, 6]
n = input()
s = 0
for c in n:
  s += a[int(c)]
print(s)
