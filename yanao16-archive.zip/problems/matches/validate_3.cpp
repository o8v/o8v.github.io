﻿#include "testlib.h"

using namespace std;

int main() {
  registerValidation();

  string s = inf.readString();
  ensure(s.size() < 100);

  inf.readEof();
  return 0;
}
