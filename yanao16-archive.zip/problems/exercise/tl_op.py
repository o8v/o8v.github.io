s = input()
last = len(s) - 1 - s.rfind(".")
best = 0
while "+" * best in s:
  best += 1
print(last, best - 1)
