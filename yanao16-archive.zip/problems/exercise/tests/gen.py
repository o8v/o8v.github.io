﻿import random
random.seed(1718)

test_number = 1
def write_test(s):
  global test_number
  o = open("%02d" % test_number, "w")
  print(s, file = o)
  o.close()
  test_number += 1

def random_string(n, p, q):
  a = []
  for i in range(n):
    if random.randint(1, p + q) <= p:
      a.append(".")
    else:
      a.append("+")
  return "".join(a)

def random2(n, p, q, swaps):
  a = []
  for i in range(p * n // (p + q)):
    a.append(".")
  while len(a) < n:
    a.append("+")
  for i in range(swaps):
    j = random.randint(0, n - 1)
    k = random.randint(0, n - 1)
    a[j], a[k] = a[k], a[j]
  return "".join(a)

write_test(random_string(1, 1, 0))
write_test(random_string(3, 1, 1))
write_test(random2(10, 1, 1, 5))
write_test(random_string(98, 0, 1))
write_test(random_string(99, 1, 0))
write_test(random_string(19, 1, 10))
write_test(random_string(20, 5, 20))
write_test(random2(21, 20, 10, 0))
write_test(random_string(22, 30, 20))
write_test(random2(23, 5, 20, 5))

for i in range(1, 11):
  if random.randint(0, 1) == 0:
    write_test(random_string(89 + i, 50,  i * 5))
  else:
    write_test(random2(89 + i, 50,  i * 5, 5 * random.randint(1, 10)))
for i in range(1, 11):
  if random.randint(0, 1) == 0:
    write_test(random_string(89 + i, i * 5, 50))
  else:
    write_test(random2(89 + i, i * 5, 50, 5 * random.randint(1, 10)))

for i in range(10):
  if random.randint(0, 1) == 0:
    write_test(random_string(900 + random.randint(0, 99),
                            random.randint(1, 10), random.randint(1, 10)))
  else:
    write_test(random2(900 + random.randint(0, 99), random.randint(1, 10),
              random.randint(1, 10), 10 * random.randint(1, 10)))

for i in range(10):
    write_test(random2(99900 + random.randint(0, 99), random.randint(1, 2),
                      random.randint(8, 10), random.randint(1, 100)))
