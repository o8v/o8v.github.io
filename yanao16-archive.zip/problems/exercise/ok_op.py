s = input() + "."

best = 0
group = 0
last = 0
for c in s:
  if c == "+":
    group += 1
  else:    
    best = max(best, group)
    last = group
    group = 0

print(last, best)