s = input()
n = len(s)

# longest
i = 0
k = 0
while i != n - 1:
  if s[i + 1] != 'x':
    i += 1
  elif i + 2 < n and s[i + 2] != 'x':
    i += 2
  else:
    print("No way!")
  k += 1
print(k)

# shortest + number of shortest
q = [(None, 0)] * n
q[0] = (0, 1)
for i in range(n):
  if q[i][0] is not None:
    x0, y0 = q[i]
    for delta in range(1, 3):
      if i + delta < n and s[i + delta] != 'x':
        x1, y1 = q[i + delta]
        if x1 is None or x0 + 1 < x1:
          q[i + delta] = x0 + 1, y0
        elif x1 == x0 + 1:
          q[i + delta] = x1, y1 + y0
print(q[-1][0])
print(q[-1][1])

# number of paths
dp = [0] * n
dp[0] = 1
for i in range(n):
  if dp[i] is not None:
    if i + 1 < n and s[i + 1] != 'x': dp[i + 1] += dp[i]
    if i + 2 < n and s[i + 2] != 'x': dp[i + 2] += dp[i]
print(dp[-1])

# A
pd = [0] * n
pd[-1] = 1
for i in range(n - 1, 0, -1):
  if pd[i] is not None:
    if i - 1 >= 0 and s[i - 1] != 'x': pd[i - 1] += pd[i]
    if i - 2 >= 0 and s[i - 2] != 'x': pd[i - 2] += pd[i]
k = s.index("A")
print(dp[k] * pd[k])

