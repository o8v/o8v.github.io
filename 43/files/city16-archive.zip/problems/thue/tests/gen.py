﻿import random
random.seed(1719)

test_number = 1
def write_test(x):
  global test_number
  o = open("%02d" % test_number, "w")
  print(x, file = o)
  o.close()
  test_number += 1

a = list(range(1, 33))
random.shuffle(a)
for i in range(10):
  write_test(a[i])

for i in range(10):
  write_test(random.randint(100, 1000))

for i in range(10):
  write_test(random.randint(90000, 100000))

for i in range(10):
  write_test(random.randint(999900000, 1000000000))
