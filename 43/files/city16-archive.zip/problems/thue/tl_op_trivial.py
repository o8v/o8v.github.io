def calc(n):
  if n == 1: return 0
  a = [0] * n  
  p = 1
  while True:
    for i in range(p, p + p):
      a[i] = 1 - a[i - p]
      if i == n - 1:
        return a[i]
    p = p * 2

n = int(input())
print(calc(n))
