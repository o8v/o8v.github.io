n = int(input())

p = 1
while p < n:
  p  = 2 * p

i = 0
while p > 1:
  q = p // 2
  if n > q:
    i = 1 - i
    n -= q
  p = q

print(i)