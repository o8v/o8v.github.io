n = int(input())

a = "0"
b = "1"

while len(a) < n:
  a, b = a + b, b + a

print(a[n - 1])