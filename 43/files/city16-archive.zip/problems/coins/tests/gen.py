﻿from random import seed, randrange as rr
seed(1723)

test_number = 1
def write_test(x):
  global test_number
  o = open("%02d" % test_number, "w")
  print(x, file = o)
  o.close()
  test_number += 1

for i in range(3, 23):
  write_test(i)
