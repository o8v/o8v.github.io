n = int(input())
a = [[False] * (n * 10 + 1) for i in range(n + 1)]
a[0][0] = True

for step in range(n):
  for i in range(step * 10 + 1):
    if a[step][i]:
      for x in [1, 2, 5, 10]:
        a[step + 1][i + x] = True

k = 0
for x in a[n]:
  if x:
    k += 1
print(k)
