n = int(input())

a = [0]
for step in range(n):
  b = []
  for x in a:
    if x + 1 not in b: b.append(x + 1)
    if x + 2 not in b: b.append(x + 2)
    if x + 5 not in b: b.append(x + 5)
    if x + 10 not in b: b.append(x + 10)
  a = b[:]

print(len(a))

  