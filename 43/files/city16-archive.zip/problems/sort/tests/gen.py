﻿from random import seed, shuffle, randrange as rr
seed(1721)

test_number = 1
def write_test(a):
  global test_number
  o = open("%02d" % test_number, "w")
  print(len(a), file = o)
  print(*a, file = o)
  o.close()
  test_number += 1

# Returns permutation with given cycles
def perm(c):
  a = []
  k = 0
  for x in c:
    a.append(k + x - 1)
    for j in range(x - 1):
      a.append(k + j)
    k += x
  p = list(range(len(a)))
  shuffle(p)
  b = [0] * len(a)
  for i in range(len(a)):
    b[p[i]] = p[a[i]] + 1
  return b

# perm, <= 10
write_test(perm([1, 2, 3]))
write_test(perm([3]))
write_test(perm([3, 3]))
write_test(perm([2, 2, 3, 3]))
write_test(perm([2, 2, 2, 2, 2]))

# perm, <= 1000
write_test(perm([1, 2, 997]))
write_test(perm([498, 499]))
write_test(perm([1] * 500 + [200, 300]))
write_test(perm([3] * 200 + [200, 200]))
write_test(perm([4] * 250))
for i in range(5):
  write_test(perm([rr(1, 5) for i in range(rr(200, 251))]))
for i in range(5):
  write_test(perm([rr(14, 21) for i in range(rr(40, 51))]))
for i in range(5):
  write_test(perm([rr(40, 51) for i in range(rr(15, 21))]))

# perm, <= 100000
write_test(perm([1, 2, 99765]))
write_test(perm([49812, 49934]))
write_test(perm([1] * 10000 + [20000, 30000, 40000]))
write_test(perm([3] * 20000 + [20000, 20000]))
for i in range(4):
  write_test(perm([rr(19900, 20000) for i in range(rr(3, 6))]))
for i in range(4):
  write_test(perm([rr(900, 1000) for i in range(rr(90, 100))]))
for i in range(4):
  write_test(perm([rr(40, 50) for i in range(rr(1900, 2000))]))
for i in range(4):
  write_test(perm([rr(7, 10) for i in range(rr(9900, 10000))]))
