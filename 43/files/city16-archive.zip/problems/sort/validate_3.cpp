﻿#include "testlib.h"

using namespace std;

int main() {
  registerValidation();

  int n = inf.readInt(1, 100000); inf.readEoln();

  vector<int> a;
  for (int i = 0; i < n; i += 1) {
    if (i > 0)
      inf.readSpace();
    a.push_back(inf.readInt(1, n));
  }  
  inf.readEoln();
  inf.readEof();

  sort(begin(a), end(a));
  for (int i = 1; i < n; i += 1)
    ensure(a[i] != a[i - 1]);

  return 0;
}
