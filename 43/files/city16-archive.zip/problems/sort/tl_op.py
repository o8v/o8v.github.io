n = int(input())
a = [int(x) for x in input().split()]
b = a[:]
b.sort()

k = 0
for i in range(n):
  if a[i] != b[i]:
    j = i
    while b[j] == b[i] or a[j] != b[i]:
      j += 1 
    a[j] = a[i]
    a[i] = b[i]
    k += 1

print(k)
