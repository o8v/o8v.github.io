n = int(input())
s = input()
a = [(int(x) - 1) for x in s.split()]

n = len(a)
for i in range(len(a)):
  if a[i] is not None:
    n -= 1
    j = a[i]
    while j != i:
      x = a[j]      
      a[j] = None
      j = x
    a[i] = None

print(n)

