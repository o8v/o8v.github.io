n = int(input())
a = [int(x) - 1 for x in input().split()]

k = 0
for i in range(n):
  while a[i] != i:
    j = a[i]
    a[i] = a[j]
    a[j] = j
    k += 1

print(k)