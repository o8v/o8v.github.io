#include <iostream>
#include <vector>

using namespace std;

int main() {
  int n;
  cin >> n;

  vector<int> a(n);
  for (auto &x : a) {
    cin >> x;
    x -= 1;
  }

  int k = 0;
  for (auto i = 0; i < a.size(); i += 1)
    if (i != a[i]) {
      int j = i + 1;
      while (a[j] != i)
        j += 1;

      a[j] = a[i];
      a[i] = i;
      k += 1;
    }

  cout << k;

  return 0;
}