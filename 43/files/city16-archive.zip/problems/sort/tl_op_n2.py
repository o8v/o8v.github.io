n = int(input())
a = [int(x) - 1 for x in input().split()]

k = 0
for i in range(n):
  j = 0
  while a[j] != i:
    j += 1
  if j == i:
    continue
  k += 1
  a[j] = a[i]
  a[i] = i

print(k)