s = input()

a = []
for c in s:
  if c >= "a" and c <= "z":
    i = (ord(c) - ord("a") + 13) % 26
    a.append(chr(ord("a") + i))
  elif c >= "A" and c <= "Z":
    i = (ord(c) - ord("A") + 13) % 26
    a.append(chr(ord("A") + i))
  else:
    a.append(c)

print("".join(a))