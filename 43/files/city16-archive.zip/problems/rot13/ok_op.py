a1 = "abcdefghijklmnopqrstuvwxyz"
a2 = "nopqrstuvwxyzabcdefghijklm"
A1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
A2 = "NOPQRSTUVWXYZABCDEFGHIJKLM"

s = input()
a = []
for c in s:
  if c in a1:
    i = a1.find(c)  
    a.append(a2[i])
  elif c in A1:
    i = A1.find(c)  
    a.append(A2[i])
  else:
    a.append(c)

print("".join(a))