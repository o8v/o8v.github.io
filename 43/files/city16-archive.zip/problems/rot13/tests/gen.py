﻿from random import seed, randrange as rr
seed(1721)

test_number = 1
def write_test(x):
  global test_number
  o = open("%02d" % test_number, "w")
  print(x, file = o)
  o.close()
  test_number += 1

g1 = "qazwsxedcrfvtgbyhnujmikolp"
g2 = "0123456789 ,.?!-"

def rand_string(s, n):
  a = []
  for i in range(n):
    a.append(s[rr(len(s))])
  return "".join(a)

for i in range(10):
  write_test(rand_string(g1, rr(5, 30)))
for i in range(10):
  write_test(rand_string(g1, rr(10, 100)))

for i in range(10):
  write_test(rand_string(g1 + g2, rr(10, 100)))
