def f(x):
  k = 0
  x -= 1
  while x > 0:
    if x % 2 == 1:
      k += 1
    x = x // 2
  return k % 2

for test in range(5):
  n = int(input())
  print(f(n), f(n + 1), f(n + 2), sep = "")
