def f(x):
  p = 1
  while p < x:
    p *= 2
  r = 0
  while p > 0:
    if x > p:
      x -= p
      r = 1 - r
    p = p // 2  
  return r

for test in range(5):
  n = int(input())
  print(f(n), f(n + 1), f(n + 2), sep = "")
