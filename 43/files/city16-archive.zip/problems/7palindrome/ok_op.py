for test in range(5):
  n = int(input())
  while True:
    n += 1
    s = str(n)
    if s == s[::-1]:
      print(n)
      break
