#include "testlib.h"
#include <sstream>

#define TESTS 5

using namespace std;

int main(int argc, char * argv[])
{
  registerTestlibCmd(argc, argv);

  string jury[TESTS];
  for (int i = 0; i < TESTS; ++i) {
    jury[i] = ans.readWord();   
  }

  int scorePerTest = (100 / TESTS);
  int score = 0;

  ostringstream passed;
  passed << "Частичное решение. Даны правильно ответы на вопросы";

  int t = 0;
  while (!ouf.seekEof()) {
    if (t >= 0 && t < TESTS) {
      string p = ouf.readWord();
      if (jury[t] == p) {
        score += scorePerTest;
        passed << " ";
        passed << (t + 1);
      }
    }
    ouf.nextLine();
    t++;
  }

  if (score == 100)
    quit(_ok, "");
  else {
    fprintf(stderr, "%s.\n", passed.str().c_str());
    printf("%d\n", score);
    quit(_wa, "");
  }
}
